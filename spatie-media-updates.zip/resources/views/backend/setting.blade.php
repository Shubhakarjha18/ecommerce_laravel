@extends('backend.layouts.master')

@section('main-content')

<div class="card">
    <h5 class="card-header">Edit Post</h5>
    <div class="card-body">
    <form method="post" action="{{route('settings.update')}}" enctype="multipart/form-data">
        @csrf 
        {{-- @method('PATCH') --}}
        {{-- {{dd($data)}} --}}
        <div class="form-group">
          <label for="short_des" class="col-form-label">Short Description <span class="text-danger">*</span></label>
          <textarea class="form-control" id="quote" name="short_des">{{$data->short_des}}</textarea>
          @error('short_des')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="description" class="col-form-label">Description <span class="text-danger">*</span></label>
          <textarea class="form-control" id="description" name="description">{{$data->description}}</textarea>
          @error('description')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="inputLogo" class="col-form-label">Logo <span class="text-danger">*</span></label>
          @php $current_logo = $data->hasMedia('logo') ? $data->getFirstMediaUrl('logo') : $data->logo; @endphp
          @if($current_logo)
          <div><img src="{{$current_logo}}" alt="current logo" style="max-height:100px;margin-bottom:10px;"></div>
          @endif
          <input id="inputLogo" class="form-control" type="file" name="logo" accept="image/*">
          <img id="holder1" src="#" alt="preview" style="margin-top:15px;max-height:100px;display:none;">

          @error('logo')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="inputPhoto" class="col-form-label">Photo <span class="text-danger">*</span></label>
          @php $current_photo = $data->hasMedia('photo') ? $data->getFirstMediaUrl('photo') : $data->photo; @endphp
          @if($current_photo)
          <div><img src="{{$current_photo}}" alt="current photo" style="max-height:100px;margin-bottom:10px;"></div>
          @endif
          <input id="inputPhoto" class="form-control" type="file" name="photo" accept="image/*">
          <img id="holder" src="#" alt="preview" style="margin-top:15px;max-height:100px;display:none;">

          @error('photo')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group">
          <label for="address" class="col-form-label">Address <span class="text-danger">*</span></label>
          <input type="text" class="form-control" name="address" required value="{{$data->address}}">
          @error('address')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="email" class="col-form-label">Email <span class="text-danger">*</span></label>
          <input type="email" class="form-control" name="email" required value="{{$data->email}}">
          @error('email')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>
        <div class="form-group">
          <label for="phone" class="col-form-label">Phone Number <span class="text-danger">*</span></label>
          <input type="text" class="form-control" name="phone" required value="{{$data->phone}}">
          @error('phone')
          <span class="text-danger">{{$message}}</span>
          @enderror
        </div>

        <div class="form-group mb-3">
           <button class="btn btn-success" type="submit">Update</button>
        </div>
      </form>
    </div>
</div>
<!-- Visit 'codeastro' for more projects -->
@endsection

@push('styles')
<link rel="stylesheet" href="{{asset('backend/summernote/summernote.min.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />

@endpush
@push('scripts')
<script src="{{asset('backend/summernote/summernote.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

<script>
    $('#inputPhoto').change(function(){
        var input=this;
        if(input.files && input.files[0]){
            var reader=new FileReader();
            reader.onload=function(e){ $('#holder').attr('src',e.target.result).show(); }
            reader.readAsDataURL(input.files[0]);
        }
    });

    $('#inputLogo').change(function(){
        var input=this;
        if(input.files && input.files[0]){
            var reader=new FileReader();
            reader.onload=function(e){ $('#holder1').attr('src',e.target.result).show(); }
            reader.readAsDataURL(input.files[0]);
        }
    });

    $(document).ready(function() {
    $('#summary').summernote({
      placeholder: "Write short description.....",
        tabsize: 2,
        height: 150
    });
    });

    $(document).ready(function() {
      $('#quote').summernote({
        placeholder: "Write short Quote.....",
          tabsize: 2,
          height: 100
      });
    });
    $(document).ready(function() {
      $('#description').summernote({
        placeholder: "Write detail description.....",
          tabsize: 2,
          height: 150
      });
    });
</script>
@endpush